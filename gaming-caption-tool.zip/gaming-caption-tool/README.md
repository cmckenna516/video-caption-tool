# 🎮 Gaming Caption Tool

Automated TikTok/Reels-style caption workflow for gaming content — built for creators using DaVinci Resolve who want large, bold hardcoded captions without relying on CapCut or manual work.

**Full workflow:** Export clip from DaVinci → generate SRT via Whisper → burn captions with FFmpeg → ready-to-post MP4.

---

## What's in this repo

| File | What it does |
|---|---|
| `MakeCaptions.py` | Drag-and-drop: generates `.srt` files from video using Whisper large-v3 |
| `burn_captions.py` | Batch caption burner: burns `.srt` captions into video using FFmpeg |
| `captionminimalv2.bat` | Windows batch alternative to `MakeCaptions.py` (uses Whisper medium) |
| `srt_from_json.py` | Companion to the `.bat` — converts Whisper JSON → SRT with gap detection |
| `video-caption-burner.skill` | Claude Cowork skill — install this to automate the burn step via AI |

---

## Prerequisites

### FFmpeg (required for burning captions)
```bash
# Windows: download from https://ffmpeg.org/download.html and add to PATH
# macOS:
brew install ffmpeg
# Linux:
sudo apt install ffmpeg
```

### Python + Whisper (required for generating SRTs)
```bash
pip install openai-whisper
```

> Whisper will download the model on first run (~1.5 GB for large-v3, ~1 GB for medium).

---

## Step 1 — Generate SRT caption files

### Option A: MakeCaptions.py (recommended)
Drag one or more video files onto `MakeCaptions.py` in Windows Explorer.

Or run from terminal:
```bash
py MakeCaptions.py "clip1.mov" "clip2.mov"
```

This runs Whisper large-v3 and saves a `.srt` file next to each video. Large-v3 gives the best accuracy — if it's too slow on your machine, open `MakeCaptions.py` and change `MODEL = "large-v3"` to `MODEL = "medium"`.

### Option B: captionminimalv2.bat (Windows, uses medium model)
Drag video files onto `captionminimalv2.bat`. Requires `srt_from_json.py` in the same folder. Uses Whisper medium with word-level timestamps for tighter caption breaks.

---

## Step 2 — Burn captions into videos

Once you have matching `.srt` and video files in the same folder, run:

```bash
python3 burn_captions.py --input-dir "C:\path\to\your\clips" --recursive
```

### What it does
- Finds every video that has a matching `.srt` (same filename, different extension)
- Skips videos with no SRT
- Skips videos already rendered (safe to re-run after interruptions)
- Creates output folders automatically

### Output folder naming
| Source | Output folder |
|---|---|
| Root folder | `Captioned Renders/` |
| `Fortnite Workspace/` | `Captioned (Fortnite Workspace) Renders/` |
| Any subfolder | `Captioned ({folder name}) Renders/` |

Output files are named `{original_name}_captioned.mp4`.

---

## Caption style

Default style is TikTok/Reels auto-caption style:

- **Font:** Nimbus Sans Bold (system font on Linux; use `--font-file` for custom fonts on Windows)
- **Color:** White text, black outline
- **Position:** Lower third, centered
- **Quality:** CRF 18 H.264 + AAC (near-lossless)
- **Scaling:** Font size and outline scale automatically to match video dimensions

---

## Using a custom font

**By name** (must be installed on the system):
```bash
python3 burn_captions.py --input-dir ".\clips" --font-name "Impact"
```

**By file** (most reliable — works with any .ttf/.otf):
```bash
python3 burn_captions.py --input-dir ".\clips" --font-file "C:\Windows\Fonts\AGENCYB.TTF"
```

Good choices: `Lato Black`, `Poppins Bold`, `Montserrat Black`, `Raleway Black`, `Impact`, `Agency FB`

---

## All options

```
python3 burn_captions.py --help

--input-dir       Folder with video + SRT files (required)
--recursive       Also process immediate subfolders
--font-name       Font family name (default: Nimbus Sans)
--font-file       Path to .ttf/.otf file (most reliable on Windows)
--font-size       Base font size at 1920px height (default: 90)
--margin-v        Vertical margin from bottom at 1920px (default: 600)
--outline         Outline thickness at 1920px height (default: 4)
--crf             FFmpeg quality — lower = better (default: 18)
--preset          FFmpeg speed preset (default: medium)
--output-suffix   Output filename suffix (default: _captioned)
```

---

## Claude Cowork skill

If you use [Claude Cowork](https://claude.ai), install `video-caption-burner.skill` by dragging it into your Cowork session. Once installed, you can just tell Claude:

> *"The SRTs are ready — apply captions to everything"*

…and it will run the batch automatically.

---

## Workflow summary

```
1. Export clips from DaVinci Resolve (.mov or .mp4)
2. Drop clips onto MakeCaptions.py → generates .srt files next to each clip
3. Run burn_captions.py --input-dir "your folder" --recursive
4. Pick up finished MP4s from the "Captioned Renders" subfolder
5. Post to TikTok / YouTube Shorts / Reels
```

---

## Troubleshooting

**Captions are the wrong size** — use `--font-size 110` (bigger) or `--font-size 70` (smaller)

**Captions too low / covering watermarks** — increase `--margin-v` (e.g. `--margin-v 700`)

**Wrong font / font not found** — use `--font-file` with a full path to a `.ttf` file

**Script stops mid-batch** — just re-run; already-done files are automatically skipped

**Corrupted output (won't play)** — the script auto-detects and deletes broken renders so they re-render on the next run

**"ffmpeg not found"** — install FFmpeg and make sure it's on your system PATH

**Whisper is slow** — change `MODEL = "large-v3"` to `MODEL = "medium"` in `MakeCaptions.py`
