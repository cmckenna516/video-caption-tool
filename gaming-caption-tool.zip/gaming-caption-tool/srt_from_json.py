"""
srt_from_json.py  —  companion to captionminimalv2.bat

Converts a Whisper word-level JSON file into a gap-aware SRT caption file.

Usage (called automatically by the .bat):
    py srt_from_json.py <input.json> <output.srt> <gap_threshold> <max_words> <max_chars>

Arguments:
    input.json      Whisper JSON output (must have been run with --word_timestamps True)
    output.srt      Destination .srt file
    gap_threshold   Seconds of silence that forces a new caption (e.g. 0.5)
    max_words       Maximum words per caption entry (e.g. 4)
    max_chars       Maximum characters per caption line (e.g. 24)
"""

import json
import sys
from pathlib import Path


def ms_to_srt_time(ms: int) -> str:
    """Convert milliseconds to SRT timestamp format: HH:MM:SS,mmm"""
    h   =  ms // 3_600_000
    ms  -= h * 3_600_000
    m   =  ms // 60_000
    ms  -= m * 60_000
    s   =  ms // 1_000
    ms  -= s * 1_000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def extract_words(whisper_json: dict) -> list:
    """
    Pull every word + its start/end time out of a Whisper JSON object.
    Returns a list of (word_text, start_sec, end_sec) tuples.
    """
    words = []
    for segment in whisper_json.get("segments", []):
        for w in segment.get("words", []):
            text  = w.get("word", "").strip()
            start = float(w.get("start", 0))
            end   = float(w.get("end",   0))
            if text:
                words.append((text, start, end))
    return words


def group_into_captions(words: list,
                        gap_threshold: float,
                        max_words: int,
                        max_chars: int) -> list:
    """
    Group word tuples into caption entries.

    A new caption starts when any of these conditions is met:
      - The silence gap between the previous word and the current word
        exceeds gap_threshold
      - Adding the next word would exceed max_words
      - Adding the next word would exceed max_chars
      - The previous word ended a sentence (. ! ?)

    Returns a list of (start_sec, end_sec, text) tuples.
    """
    captions = []
    current_words = []
    current_start = 0.0
    current_end   = 0.0

    def flush():
        if current_words:
            text = " ".join(w for w, _, _ in current_words)
            captions.append((current_start, current_end, text))

    sentence_enders = {'.', '!', '?'}

    for i, (text, start, end) in enumerate(words):
        if not current_words:
            current_words = [(text, start, end)]
            current_start = start
            current_end   = end
            continue

        gap          = start - current_end
        joined_text  = " ".join(w for w, _, _ in current_words) + " " + text
        would_break  = False

        if gap > gap_threshold:
            would_break = True
        elif len(current_words) >= max_words:
            would_break = True
        elif len(joined_text) > max_chars:
            would_break = True
        elif current_words and current_words[-1][0].rstrip()[-1:] in sentence_enders:
            would_break = True

        if would_break:
            flush()
            current_words = [(text, start, end)]
            current_start = start
            current_end   = end
        else:
            current_words.append((text, start, end))
            current_end = end

        # If this word ends a sentence, flush immediately
        if text.rstrip()[-1:] in sentence_enders:
            flush()
            current_words = []

    flush()
    return captions


def write_srt(captions: list, output_path: str) -> None:
    """Write a list of (start_sec, end_sec, text) tuples to an SRT file."""
    lines = []
    for idx, (start, end, text) in enumerate(captions, start=1):
        start_ms = int(start * 1000)
        end_ms   = int(end   * 1000)
        # Ensure minimum caption duration of 300 ms
        if end_ms - start_ms < 300:
            end_ms = start_ms + 300
        lines.append(str(idx))
        lines.append(f"{ms_to_srt_time(start_ms)} --> {ms_to_srt_time(end_ms)}")
        lines.append(text)
        lines.append("")
    Path(output_path).write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def main():
    if len(sys.argv) < 6:
        print("Usage: srt_from_json.py <input.json> <output.srt> "
              "<gap_threshold> <max_words> <max_chars>")
        sys.exit(1)

    json_path      = sys.argv[1]
    srt_path       = sys.argv[2]
    gap_threshold  = float(sys.argv[3])
    max_words      = int(sys.argv[4])
    max_chars      = int(sys.argv[5])

    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    words    = extract_words(data)
    captions = group_into_captions(words, gap_threshold, max_words, max_chars)
    write_srt(captions, srt_path)

    print(f"OK: wrote {len(captions)} captions to {srt_path}")


if __name__ == "__main__":
    main()
