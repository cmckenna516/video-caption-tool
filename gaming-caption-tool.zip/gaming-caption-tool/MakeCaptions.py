"""
MakeCaptions.py — Drag and drop videos onto this script to generate SRT files.

- Uses Whisper large-v3 for accurate transcription
- Saves the SRT right next to each video
- Shows progress as it runs
- Handles multiple files at once

Usage: Drag one or more video files onto this .py file in Windows Explorer.
       Or run from terminal: py MakeCaptions.py "video1.mov" "video2.mov"
"""

import subprocess
import sys
import os

# ── Settings ──────────────────────────────────────────────────────────────────

MODEL    = "large-v3"   # Change to "medium" if large-v3 is too slow
LANGUAGE = "en"

# ─────────────────────────────────────────────────────────────────────────────

VIDEO_EXTENSIONS = {".mov", ".mp4", ".mkv", ".avi", ".webm", ".m4v"}

def transcribe(video_path):
    video_path = os.path.abspath(video_path)
    output_dir = os.path.dirname(video_path)
    name       = os.path.splitext(os.path.basename(video_path))[0]

    print(f"\n{'─' * 60}")
    print(f"Processing : {os.path.basename(video_path)}")
    print(f"Output SRT : {name}.srt")
    print(f"Model      : {MODEL}")
    print(f"{'─' * 60}")

    cmd = [
        "py", "-m", "whisper",
        video_path,
        "--model",         MODEL,
        "--language",      LANGUAGE,
        "--output_format", "srt",
        "--output_dir",    output_dir,
        "--fp16",          "False",
        "--task",          "transcribe",
    ]

    result = subprocess.run(cmd)

    srt_path = os.path.join(output_dir, name + ".srt")
    if result.returncode == 0 and os.path.exists(srt_path):
        size = os.path.getsize(srt_path)
        print(f"\n✓ Done — {name}.srt ({size} bytes)")
        return True
    else:
        print(f"\n✗ Failed — check that Whisper is installed: py -m pip install openai-whisper")
        return False


def main():
    files = [f for f in sys.argv[1:]
             if os.path.splitext(f)[1].lower() in VIDEO_EXTENSIONS]

    if not files:
        print("=" * 60)
        print("  MakeCaptions.py")
        print("=" * 60)
        print("\n  Drag and drop video files onto this script to")
        print("  generate SRT caption files using Whisper.\n")
        print("  Supported formats: .mov .mp4 .mkv .avi .webm .m4v")
        print("\n  No video files detected — nothing to do.")
        input("\nPress Enter to exit...")
        return

    print(f"\n{'=' * 60}")
    print(f"  MakeCaptions.py — {len(files)} file(s) to process")
    print(f"{'=' * 60}")

    ok   = 0
    fail = 0
    for f in files:
        if transcribe(f):
            ok += 1
        else:
            fail += 1

    print(f"\n{'=' * 60}")
    print(f"  Done — {ok} succeeded, {fail} failed")
    print(f"{'=' * 60}\n")
    input("Press Enter to exit...")


if __name__ == "__main__":
    main()
