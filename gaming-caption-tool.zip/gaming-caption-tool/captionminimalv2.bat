@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM =====================================
REM CaptionMinimalV2 - TikTok-style SRT for DaVinci Resolve
REM Drag & drop MANY .MOV (or other) files onto this .bat
REM Output: creates ONLY <video_name>.srt next to each video
REM (Uses a TEMP folder internally; cleans up after.)
REM =====================================

REM ── Tuning knobs ──────────────────────────────────────────
REM GAP_THRESHOLD: seconds of silence that forces a caption break
REM  Lower  = more breaks (e.g. 0.3 splits on short pauses)
REM  Higher = fewer breaks (e.g. 1.0 only splits on obvious pauses)
set "GAP_THRESHOLD=0.5"

REM MAX_WORDS: max words per caption entry
set "MAX_WORDS=4"

REM MAX_CHARS: max characters per caption line
set "MAX_CHARS=24"
REM ──────────────────────────────────────────────────────────

REM Location of the converter script (same folder as this .bat)
set "SCRIPTDIR=%~dp0"
set "CONVERTER=%SCRIPTDIR%srt_from_json.py"

if not exist "%CONVERTER%" (
  echo.
  echo ERROR: srt_from_json.py not found at: %CONVERTER%
  echo Make sure srt_from_json.py is in the same folder as this .bat
  echo.
  pause
  exit /b 1
)

if "%~1"=="" (
  echo.
  echo Drag and drop one or more video files onto this .bat.
  echo.
  pause
  exit /b 1
)

set "TMPROOT=%TEMP%\whisper_srt_out"
if not exist "%TMPROOT%" mkdir "%TMPROOT%" >nul 2>&1

echo.
echo === Starting caption batch ===
echo     Gap threshold : %GAP_THRESHOLD%s
echo     Max words     : %MAX_WORDS%
echo     Max chars     : %MAX_CHARS%
echo.

for %%F in (%*) do (
  call :PROCESS_ONE "%%~fF"
)

echo.
echo =====================================
echo ALL FILES COMPLETE
echo =====================================
echo.
pause
exit /b 0

:PROCESS_ONE
set "INFILE=%~1"
set "VIDDIR=%~dp1"
set "BASENAME=%~n1"

REM Safe temp dir per file (prevents collisions)
set "TMPDIR=%TMPROOT%\%BASENAME%_%RANDOM%"
if exist "%TMPDIR%" rmdir /s /q "%TMPDIR%" >nul 2>&1
mkdir "%TMPDIR%" >nul 2>&1

set "OUTSRT=%VIDDIR%%BASENAME%.srt"
set "LOGFILE=%TMPDIR%\whisper.log"

echo -------------------------------------
echo Processing: %INFILE%
echo Output:     %OUTSRT%

REM Run Whisper -> write JSON into temp folder
REM JSON output includes word-level timestamps needed for gap detection
py -m whisper "%INFILE%" --model medium --language en --task transcribe --output_dir "%TMPDIR%" --output_format json --word_timestamps True --condition_on_previous_text False --no_speech_threshold 0.4 --hallucination_silence_threshold 0.2 --fp16 False > "%LOGFILE%" 2>&1

if errorlevel 1 (
  echo.
  echo ERROR: Whisper failed for: %INFILE%
  echo Showing log tail:
  echo -------------------------------------
  call :TAIL "%LOGFILE%" 25
  echo -------------------------------------
  echo.
  echo Fix tip: If the log mentions ffmpeg, install ffmpeg and ensure it is on PATH.
  echo.
  rmdir /s /q "%TMPDIR%" >nul 2>&1
  exit /b 0
)

REM Whisper should produce: <basename>.json inside TMPDIR
if not exist "%TMPDIR%\%BASENAME%.json" (
  echo.
  echo ERROR: No JSON was produced for: %INFILE%
  echo Showing log tail:
  echo -------------------------------------
  call :TAIL "%LOGFILE%" 25
  echo -------------------------------------
  echo.
  rmdir /s /q "%TMPDIR%" >nul 2>&1
  exit /b 0
)

REM Convert JSON -> SRT using gap-aware Python script
echo Converting JSON to SRT with gap threshold %GAP_THRESHOLD%s ...
py "%CONVERTER%" "%TMPDIR%\%BASENAME%.json" "%TMPDIR%\%BASENAME%.srt" %GAP_THRESHOLD% %MAX_WORDS% %MAX_CHARS%

if errorlevel 1 (
  echo.
  echo ERROR: SRT conversion failed for: %INFILE%
  echo.
  rmdir /s /q "%TMPDIR%" >nul 2>&1
  exit /b 0
)

if not exist "%TMPDIR%\%BASENAME%.srt" (
  echo.
  echo ERROR: No SRT was produced for: %INFILE%
  echo.
  rmdir /s /q "%TMPDIR%" >nul 2>&1
  exit /b 0
)

REM Copy only the SRT next to the video
copy /y "%TMPDIR%\%BASENAME%.srt" "%OUTSRT%" >nul

REM Cleanup temp folder (so your folder stays clean)
rmdir /s /q "%TMPDIR%" >nul 2>&1

if exist "%OUTSRT%" (
  echo OK: Created %OUTSRT%
) else (
  echo ERROR: Expected SRT not found at: %OUTSRT%
)

echo.
exit /b 0

:TAIL
REM Usage: call :TAIL "file" N
setlocal EnableDelayedExpansion
set "FILE=%~1"
set "N=%~2"
if not exist "!FILE!" (
  echo (no log file found)
  endlocal
  exit /b 0
)
for /f "usebackq delims=" %%L in (`powershell -NoProfile -Command "Get-Content -Path '%FILE%' -Tail %N%"`) do echo %%L
endlocal
exit /b 0
