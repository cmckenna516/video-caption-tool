#!/usr/bin/env python3
"""
burn_captions.py — Batch SRT-to-video caption burner.

Finds video+SRT pairs in a folder, generates styled ASS subtitle files,
and burns them into MP4 outputs using FFmpeg.

Usage:
  python3 burn_captions.py --input-dir /path/to/folder [options]
  python3 burn_captions.py --input-dir /path/to/root --recursive [options]
"""

import argparse
import os
import re
import subprocess
import sys

# ── Constants ────────────────────────────────────────────────────────────────

VIDEO_EXTENSIONS = {'.mov', '.mp4', '.mkv', '.avi', '.webm', '.m4v'}

DEFAULT_FONT_NAME  = 'Nimbus Sans'
DEFAULT_FONT_SIZE  = 90     # at PlayResY = 1920
DEFAULT_MARGIN_V   = 600    # at PlayResY = 1920
DEFAULT_OUTLINE    = 4      # at PlayResY = 1920
DEFAULT_CRF        = 18
DEFAULT_PRESET     = 'medium'
DEFAULT_SUFFIX     = '_captioned'

# ASS colour format: &HAABBGGRR (AA=alpha 00=opaque)
PRIMARY_COLOUR  = '&H00FFFFFF'   # white
OUTLINE_COLOUR  = '&H00000000'   # black

# ── SRT parsing ───────────────────────────────────────────────────────────────

def srt_to_ass_time(t: str) -> str:
    """Convert '00:00:03,880' → '0:00:03.88'"""
    t = t.strip().replace(',', '.')
    h, m, s = t.split(':')
    return f"{int(h)}:{m}:{s}"


def parse_srt(path: str) -> list:
    """Return list of (start_ass, end_ass, text) tuples from an SRT file."""
    with open(path, encoding='utf-8', errors='replace') as f:
        raw = f.read()

    entries = []
    for block in re.split(r'\n{2,}', raw.strip()):
        lines = block.strip().splitlines()
        if len(lines) < 3:
            continue
        timing_idx = next((i for i, l in enumerate(lines) if '-->' in l), None)
        if timing_idx is None:
            continue
        start, end = [x.strip() for x in lines[timing_idx].split('-->')]
        text = '\\N'.join(lines[timing_idx + 1:])   # ASS line break
        entries.append((srt_to_ass_time(start), srt_to_ass_time(end), text))
    return entries


# ── ASS generation ────────────────────────────────────────────────────────────

def get_video_dimensions(video_path: str):
    """Return (width, height) of a video file using ffprobe."""
    result = subprocess.run(
        ['ffprobe', '-v', 'quiet',
         '-show_entries', 'stream=width,height',
         '-of', 'csv=p=0', video_path],
        capture_output=True, text=True
    )
    for line in result.stdout.splitlines():
        parts = line.strip().split(',')
        if len(parts) == 2:
            try:
                w, h = int(parts[0]), int(parts[1])
                if w > 0 and h > 0:
                    return w, h
            except ValueError:
                continue
    return 1080, 1920   # safe fallback


def scale(value: float, actual_height: int, base_height: int = 1920) -> int:
    """Scale a pixel value proportionally to actual video height."""
    return max(1, round(value * actual_height / base_height))


def make_ass(entries: list, out_path: str, width: int, height: int,
             font_name: str, font_file: str,
             font_size: int, margin_v: int, outline: int) -> None:
    """Write a styled ASS subtitle file."""

    # Scale all size-sensitive values to match actual video dimensions
    scaled_size    = scale(font_size, height)
    scaled_margin  = scale(margin_v,  height)
    scaled_outline = scale(outline,   height)

    # If a font file is provided, ASS can reference it via @fontspath — but the
    # most reliable cross-platform approach is to copy the font to the system
    # fonts dir or use the font name after registering it. For simplicity we use
    # the font *name* in the ASS (FFmpeg's libass will search fontsdir if set),
    # but we pass --font-file to ffmpeg's fontsdir below.
    style = (
        f"Default,{font_name},{scaled_size},"
        f"{PRIMARY_COLOUR},{PRIMARY_COLOUR},{OUTLINE_COLOUR},&H00000000,"
        f"-1,0,0,0,100,100,0,0,1,{scaled_outline},0,2,20,20,{scaled_margin},1"
    )

    header = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        f"PlayResX: {width}\n"
        f"PlayResY: {height}\n"
        "ScaledBorderAndShadow: yes\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
        "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, "
        "ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: {style}\n\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(header)
        for start, end, text in entries:
            f.write(f"Dialogue: 0,{start},{end},Default,,0,0,0,,{text}\n")


# ── FFmpeg render ─────────────────────────────────────────────────────────────

def verify_output(video_path: str) -> bool:
    """Check that an output MP4 is complete and playable (moov atom present)."""
    result = subprocess.run(
        ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
         '-of', 'csv=p=0', video_path],
        capture_output=True, text=True
    )
    if result.returncode != 0 or not result.stdout.strip():
        return False
    try:
        return float(result.stdout.strip()) > 0
    except ValueError:
        return False


def render(video_in: str, ass_path: str, video_out: str,
           font_file: str, crf: int, preset: str) -> bool:
    """Burn ASS subtitles into video_in and write to video_out."""

    # If user supplied a font file, tell libass where to find it
    if font_file and os.path.isfile(font_file):
        font_dir  = os.path.dirname(os.path.abspath(font_file))
        vf_filter = f"ass={ass_path}:fontsdir={font_dir}"
    else:
        vf_filter = f"ass={ass_path}"

    cmd = [
        'ffmpeg', '-y', '-i', video_in,
        '-vf', vf_filter,
        '-c:v', 'libx264', '-crf', str(crf), '-preset', preset,
        '-c:a', 'aac', '-b:a', '192k', '-pix_fmt', 'yuv420p',
        video_out
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return False

    # Verify the output is actually playable — catches files broken by
    # mid-render interruptions (missing moov atom, incomplete write, etc.)
    if not verify_output(video_out):
        if os.path.exists(video_out):
            os.remove(video_out)  # Delete broken file so it re-renders next run
        return False
    return True


# ── Folder discovery ──────────────────────────────────────────────────────────

def output_folder_name(src_dir: str, root_dir: str) -> str:
    """
    Determine the output subfolder name.
    - Root dir → 'Captioned Renders'
    - Subfolder 'Fortnite Workspace' → 'Captioned (Fortnite Workspace) Renders'
    """
    if os.path.abspath(src_dir) == os.path.abspath(root_dir):
        return 'Captioned Renders'
    folder_name = os.path.basename(src_dir.rstrip('/\\'))
    return f'Captioned ({folder_name}) Renders'


def find_dirs(root_dir: str, recursive: bool) -> list:
    """Return list of directories to process."""
    dirs = [root_dir]
    if recursive:
        for entry in sorted(os.scandir(root_dir), key=lambda e: e.name):
            if entry.is_dir(follow_symlinks=False):
                # Skip output folders we've already created
                if 'Captioned' in entry.name and 'Renders' in entry.name:
                    continue
                dirs.append(entry.path)
    return dirs


def find_pairs(src_dir: str) -> tuple:
    """Return (pairs_list, skipped_list) where pairs = list of base names."""
    try:
        files = os.listdir(src_dir)
    except PermissionError:
        return [], []

    videos = {os.path.splitext(f)[0]
              for f in files
              if os.path.splitext(f)[1].lower() in VIDEO_EXTENSIONS}
    srts   = {os.path.splitext(f)[0]
              for f in files
              if f.lower().endswith('.srt')}

    pairs  = sorted(videos & srts)
    skipped = sorted(videos - srts)
    return pairs, skipped


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Burn SRT captions into videos using FFmpeg.')
    parser.add_argument('--input-dir', required=True,
                        help='Folder containing video + SRT files')
    parser.add_argument('--recursive', action='store_true',
                        help='Also process immediate subfolders')
    parser.add_argument('--font-name', default=DEFAULT_FONT_NAME,
                        help='Font family name (system-installed)')
    parser.add_argument('--font-file', default='',
                        help='Path to .ttf/.otf font file (overrides --font-name)')
    parser.add_argument('--font-size', type=int, default=DEFAULT_FONT_SIZE,
                        help=f'Base font size at 1920px height (default: {DEFAULT_FONT_SIZE})')
    parser.add_argument('--margin-v', type=int, default=DEFAULT_MARGIN_V,
                        help=f'Vertical margin from bottom at 1920px height (default: {DEFAULT_MARGIN_V})')
    parser.add_argument('--outline', type=int, default=DEFAULT_OUTLINE,
                        help=f'Outline thickness at 1920px height (default: {DEFAULT_OUTLINE})')
    parser.add_argument('--crf', type=int, default=DEFAULT_CRF,
                        help=f'FFmpeg quality (lower=better, default: {DEFAULT_CRF})')
    parser.add_argument('--preset', default=DEFAULT_PRESET,
                        help=f'FFmpeg speed preset (default: {DEFAULT_PRESET})')
    parser.add_argument('--output-suffix', default=DEFAULT_SUFFIX,
                        help=f'Suffix for output files (default: {DEFAULT_SUFFIX})')
    args = parser.parse_args()

    # Resolve font name from file if provided
    font_name = args.font_name
    if args.font_file and os.path.isfile(args.font_file):
        # Try to extract the font family name from the file
        try:
            from fontTools.ttLib import TTFont
            tt = TTFont(args.font_file)
            extracted = tt['name'].getDebugName(1)
            if extracted:
                font_name = extracted
                print(f"  Font file detected family: '{font_name}'")
        except Exception:
            pass   # Fall back to --font-name value

    root_dir = args.input_dir
    dirs = find_dirs(root_dir, args.recursive)

    total_ok = total_skip = total_fail = 0
    ass_tmp = '/tmp/_caption_current.ass'

    for src_dir in dirs:
        pairs, skipped = find_pairs(src_dir)
        out_folder = output_folder_name(src_dir, root_dir)
        out_dir = os.path.join(src_dir, out_folder)

        print(f"\n{'─' * 60}")
        print(f"Folder : {src_dir}")
        print(f"Output : {out_dir}")
        print(f"Pairs  : {len(pairs)}  |  No-SRT skips: {len(skipped)}")
        if skipped:
            print(f"  Skipping (no SRT): {skipped}")

        if not pairs:
            continue

        os.makedirs(out_dir, exist_ok=True)

        for name in pairs:
            # Find the actual video file (extension may vary)
            video_in = None
            for ext in VIDEO_EXTENSIONS:
                candidate = os.path.join(src_dir, name + ext)
                if os.path.isfile(candidate):
                    video_in = candidate
                    break

            srt_path  = os.path.join(src_dir, name + '.srt')
            video_out = os.path.join(out_dir, name + args.output_suffix + '.mp4')

            if os.path.isfile(video_out):
                print(f"  ✓ {name} (already done)")
                total_ok += 1
                continue

            sys.stdout.write(f"  ► {name} ... ")
            sys.stdout.flush()

            entries = parse_srt(srt_path)
            if not entries:
                print("SKIP (empty SRT)")
                total_skip += 1
                continue

            w, h = get_video_dimensions(video_in)
            make_ass(entries, ass_tmp, w, h,
                     font_name, args.font_file,
                     args.font_size, args.margin_v, args.outline)

            ok = render(video_in, ass_tmp, video_out,
                        args.font_file, args.crf, args.preset)
            if ok:
                size_mb = os.path.getsize(video_out) / 1024 / 1024
                print(f"OK ({size_mb:.1f} MB)")
                total_ok += 1
            else:
                print("FAILED")
                total_fail += 1

        total_skip += len(skipped)

    print(f"\n{'═' * 60}")
    print(f"DONE — Rendered: {total_ok}  |  Skipped: {total_skip}  |  Failed: {total_fail}")


if __name__ == '__main__':
    main()
